---
title : "Kiến trúc mô hình Rag triển khai trên AWS Agent core"
weight : 3
chapter : false
pre : " <b> 5.3. </b> "
---

#### Sử dụng Gateway endpoint

Trong phần này, chúng ta sẽ tìm hiểu cách tích hợp Groq để gọi model OpenAI-compatible và cách chunking dữ liệu cho RAG.

