---

title: "RAG Architecture Deployed on AWS AgentCore"
weight: 3
chapter: false
pre: " <b> 5.3. </b> "
----

#### Using the Gateway Endpoint

In this section, we will explore how to integrate Groq to call OpenAI-compatible models and how to perform data chunking for RAG.
