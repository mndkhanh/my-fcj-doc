---
title : "Run Agent Core"
weight : 4 
chapter : false
pre : " <b> 5.4. </b> "
---

#### Tổng quan

+ Trong phần này, bạn sẽ học cách triển khai và gọi AWS Agent Core từ máy local 
+ Tại sao nên sử dụng **AWS CLI**:
    AWS CLI có thể giúp bạn truy cập và cấu hình set up được Agent Core từ máy của mình, linh hoạt và tiện lợi
    



